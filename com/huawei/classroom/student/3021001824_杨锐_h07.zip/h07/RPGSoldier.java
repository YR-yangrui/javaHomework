package com.huawei.classroom.student.h07;

public class RPGSoldier extends Soldier {
	public RPGSoldier(int x,int y) {
		super(x, y);
	}

}
