package com.huawei.classroom.student.h06;

public class Building extends GameObject {

	public Building( int x ,int y) {
		super(x, y);
	}

	 

}
