package com.huawei.classroom.student.h05;

public class HeavyTank extends Tank{

    public HeavyTank() {
        super(200, 20);
    }
}
