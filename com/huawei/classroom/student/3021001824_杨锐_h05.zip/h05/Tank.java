package com.huawei.classroom.student.h05;

public abstract class Tank extends Unit{
    public Tank(int health, int strength) {
        super(health, strength);
    }
}
