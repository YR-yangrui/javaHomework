package com.huawei.classroom.student.h05;

public enum EnumObjectType {
    heavyTank,mediumTank,rifleSoldier,RPGSoldier,dog;
}
